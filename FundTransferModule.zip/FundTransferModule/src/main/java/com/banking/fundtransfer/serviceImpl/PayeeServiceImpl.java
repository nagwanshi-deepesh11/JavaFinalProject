package com.banking.fundtransfer.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Payee;
import com.banking.fundtransfer.exceptions.PayeeListEmptyException;
import com.banking.fundtransfer.service.PayeeService;

@Service
public class PayeeServiceImpl implements PayeeService
{

	@Override
	public List<Payee> findAllPayee()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Payee findPayeeById(int payeeId) throws PayeeListEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Payee addPayee(Payee PayeeObject) {
		// TODO Auto-generated method stub
		return null;
	}
	
	


}
