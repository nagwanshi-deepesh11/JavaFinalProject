package com.banking.fundtransfer.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Transaction;
import com.banking.fundtransfer.exceptions.TransactionListEmptyException;
import com.banking.fundtransfer.exceptions.TransactionNotFoundException;

@Service
public interface TransactionService 

{
	public List<Transaction> findAllTransaction() throws TransactionListEmptyException;

	public Transaction findTransactionByTransactionId(int transactionId) throws TransactionNotFoundException;
}
