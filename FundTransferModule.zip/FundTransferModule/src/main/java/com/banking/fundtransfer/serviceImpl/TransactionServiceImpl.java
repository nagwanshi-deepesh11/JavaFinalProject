package com.banking.fundtransfer.serviceImpl;

import java.util.List;

import com.banking.fundtransfer.entity.Transaction;
import com.banking.fundtransfer.exceptions.TransactionListEmptyException;
import com.banking.fundtransfer.exceptions.TransactionNotFoundException;
import com.banking.fundtransfer.service.TransactionService;

public class TransactionServiceImpl implements TransactionService

{

	@Override
	public List<Transaction> findAllTransaction() throws TransactionListEmptyException 
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction findTransactionByTransactionId(int transactionId) throws TransactionNotFoundException
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
