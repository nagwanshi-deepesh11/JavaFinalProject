package com.banking.fundtransfer.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Transaction;
import com.banking.fundtransfer.exceptions.*;
import com.banking.fundtransfer.repository.TransactionRepository;
import com.banking.fundtransfer.service.TransactionService;




@Service
public class TransactionServiceImpl implements TransactionService

{
	@Autowired
	TransactionRepository txnRepo;
	
	@Override
	public List<Transaction> findAllTransactionService() throws TransactionListEmptyException {
		
		List<Transaction> txnList = (List<Transaction>) txnRepo.findAll();
		if (txnList.isEmpty()) {
			throw new TransactionListEmptyException("No txns found for this user ID");
		}
		else {
			return txnList;
		}
		
	}

	@Override
	public Transaction saveTransaction(Transaction txn)
	{
		Transaction newTxn = null;
		newTxn = txnRepo.save(txn);
		
		return newTxn;
	}
	
	@Override
	public Transaction findTxnByIdService(int transactionId) throws TransactionNotFoundException 
	{
		Optional<Transaction> txn = txnRepo.findById(transactionId);
		if(txn.isPresent()) {
			return txn.get();
		}
		else {
			throw new TransactionNotFoundException("No such transaction exists");
		}
	}

	
	
	

}
