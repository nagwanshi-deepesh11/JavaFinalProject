package com.banking.fundtransfer.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Account;
import com.banking.fundtransfer.entity.Payee;
import com.banking.fundtransfer.exceptions.PayeeListEmptyException;
import com.banking.fundtransfer.exceptions.PayeeNotFoundException;

@Service
public interface PayeeService 
{

	
	public List<Payee> findAllPayee();

	public Payee findPayeeById(int payeeId) throws PayeeListEmptyException;
	
	public Payee addPayee(Payee PayeeObject);


}
