package com.banking.fundtransfer.service;

import com.banking.fundtransfer.entity.Login;

public interface LoginService
{

	public Login saveLoginService(Login LoginObj);
	public Login getLoginService(String usernName);	
	
}
