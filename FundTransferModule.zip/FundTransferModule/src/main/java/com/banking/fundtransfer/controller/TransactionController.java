package com.banking.fundtransfer.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TransactionController {

}
