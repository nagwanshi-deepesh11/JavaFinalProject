package com.banking.fundtransfer.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Login;
import com.banking.fundtransfer.repository.LoginRepository;
import com.banking.fundtransfer.service.LoginService;


@Service
public class LoginServiceImpl implements LoginService

{

	@Autowired LoginRepository loginRepository;
	
	@Override
	public Login saveLoginService(Login LoginObj) 
	
	{
		Login loginSaved =null;
		System.out.println("4 : Service Layer");
		loginSaved = loginRepository.save(LoginObj);
		System.out.println("In service layer after persist");
		
	 return loginSaved;
	}

	@Override
	public Login getLoginService(String usernName) 
	{
		Optional<Login> LoginDetails = loginRepository.findById(usernName);
		return LoginDetails.get();

	}

}
