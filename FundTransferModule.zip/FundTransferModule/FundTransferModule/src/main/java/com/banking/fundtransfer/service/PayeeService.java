package com.banking.fundtransfer.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.banking.fundtransfer.entity.Payee;
import com.banking.fundtransfer.exceptions.PayeeListEmptyException;
import com.banking.fundtransfer.exceptions.PayeeNotFoundException;

@Service
public interface PayeeService 
{

	
	public List<Payee> findAllPayeeService() throws PayeeListEmptyException;

	public Payee findPayeeByIdService(int payeeId) throws PayeeNotFoundException;
	
	public Payee addPayeeService(Payee PayeeObject);


}
