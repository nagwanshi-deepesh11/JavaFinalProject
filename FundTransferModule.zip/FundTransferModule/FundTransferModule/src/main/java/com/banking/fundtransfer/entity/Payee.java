package com.banking.fundtransfer.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Payee")
public class Payee 
{

	
@Id
@GeneratedValue
private int payeeId;

@Column(name="ContactNumber")
long contactNumber;

@Column(name="email",length=20)
String email;

@JsonIgnore
public Set<Account> getAccounts() 
{
	return accounts;
}

public void setAccounts(Set<Account> accounts) 
{
	this.accounts = accounts;
}


@Column(name="Beneficiary_Name",length=20)
private String benificiaryName;
@Column(name="Beneficairy_Account_Number")
private long beneficairyAccountNumber;
@Column(name="Beneficairy_Bank_Name", length=15)
private String beneficiaryBankName;
@Column (name="Beneficairy_Branch_Name",length=25)
private String beneficiaryBranchName;
@Column(name="Beneficairy_IFSC_CODE", length=11)
private String beneficairyIFSCCode;
@Column(name="Limit")
private long beneficairyLimit;


@ManyToMany( cascade = CascadeType.ALL)
@JoinTable(
		name="account_payee_link_table",
		joinColumns = {@JoinColumn(name="payeeId")},
		inverseJoinColumns = {@JoinColumn(name="accountId")}
)
private Set<Account> accounts;


public long getContactNumber() {
	return contactNumber;
}

public void setContactNumber(long contactNumber) {
	this.contactNumber = contactNumber;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getBenificiaryName() 
{
	return benificiaryName;
}

public void setBenificiaryName(String benificiaryName) 
{
	this.benificiaryName = benificiaryName;
}

public Payee(){
	super();
}

public long getBeneficairyAccountNumber() {
	return beneficairyAccountNumber;
}

public void setBeneficairyAccountNumber(long beneficairyAccountNumber) {
	this.beneficairyAccountNumber = beneficairyAccountNumber;
}

public String getBeneficiaryBankName() {
	return beneficiaryBankName;
}

public void setBeneficiaryBankName(String beneficiaryBankName) {
	this.beneficiaryBankName = beneficiaryBankName;
}

public String getBeneficiaryBranchName() {
	return beneficiaryBranchName;
}

public void setBeneficiaryBranchName(String beneficiaryBranchName) {
	this.beneficiaryBranchName = beneficiaryBranchName;
}

public String getBeneficairyIFSCCode() {
	return beneficairyIFSCCode;
}

public void setBeneficairyIFSCCode(String beneficairyIFSCCode) {
	this.beneficairyIFSCCode = beneficairyIFSCCode;
}

public long getBeneficairyLimit() {
	return beneficairyLimit;
}

public void setBeneficairyLimit(long beneficairyLimit) {
	this.beneficairyLimit = beneficairyLimit;
}



}
