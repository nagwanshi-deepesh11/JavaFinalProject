package com.banking.fundtransfer.exceptions;

public class TransactionNotFoundException extends Exception
{

	public TransactionNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
