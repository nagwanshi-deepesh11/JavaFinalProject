package com.banking.fundtransfer.repository;

import org.springframework.data.repository.CrudRepository;

import com.banking.fundtransfer.entity.Login;

public interface LoginRepository extends CrudRepository<Login, String>

{
	
	

}
