import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Account } from './account';


@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit 
{
 accountObj:Account = new Account();
 

 msg!:any;
  constructor(private accountService:AccountService) 
  { 

  }

  ngOnInit(): void 
  {
  this.findAccount();
  }

  findAccount() 
  {

    this.accountService.loadAccountObjectFromSpring(302).subscribe
    (
      {
        next: (data: any) =>  {
          this.accountObj = data;
          console.log(data);
          this.msg="";
        },
        complete: () => {},
        error: (error) => { 
          this.msg = error.error.message;
          this.accountObj.accountHolder="";
          this.accountObj.accountNumber;
          this.accountObj.accountType="";
          this.accountObj.balance;
          this.accountObj.contactNumber;
          this.accountObj.emailId="";
          console.log(error.error.message); }
      }
   );
  }
}
