

export class Account 
{
	
    
    accountNumber!:number;
    accountHolder!:string;
    balance!:number;
    contactNumber!:number;
    emailId!:string;
    accountType!:string;
	
}